# Display Mockups - SmartEBL Display

Visuelle Darstellung der Nextion Display-Seiten (7" - 800x480px)

---

## Home Screen (Page 0)

```
┌─────────────────────────────────────────────────────────────────────┐
│                                                                     │
│  ✓ ALL SYSTEMS NORMAL                                              │
│                                                                     │
├───────────────┬─────────────────────────────────────────────────────┤
│               │                                                     │
│   Electric    │                                                     │
│               │                                                     │
│               │                                                     │
│   Water       │              HAUPTMENÜ                              │
│               │                                                     │
│               │         SmartEBL Display System                     │
│   Climate     │                                                     │
│               │      Wähle eine Sektion aus dem Menü               │
│               │                                                     │
│   Status      │                                                     │
│               │                                                     │
│               │                                                     │
│   Power       │                                                     │
│               │                                                     │
│               │                                                     │
└───────────────┴─────────────────────────────────────────────────────┘
```

---

## Electric Page 1 (Page 1)

```
┌─────────────────────────────────────────────────────────────────────┐
│                                                                1/2  │
│  ✓ ALL SYSTEMS NORMAL                                              │
│                                                                     │
├───────────────┬─────────────────────────────────────────────────────┤
│               │                                                     │
│ ━━Electric━━  │   BATTERY STATUS                                    │
│               │                                                     │
│   Water       │   Voltage:     12.8V                                │
│               │   Current:      5.2A                                │
│   Climate     │   SOC:          78%  🟢                             │
│               │                                                     │
│   Status      │   SOLAR                                             │
│               │   Power:       245W                                 │
│   Power       │   Status:      Charging  🟢                         │
│               │                                                     │
│               │   SHORE POWER                                       │
│               │   Status:      Disconnected                         │
│               │                                                     │
│               │                                   [ Next Page → ]   │
└───────────────┴─────────────────────────────────────────────────────┘
```

---

## Electric Page 2 (Page 2)

```
┌─────────────────────────────────────────────────────────────────────┐
│                                                                2/2  │
│  ✓ ALL SYSTEMS NORMAL                                              │
│                                                                     │
├───────────────┬─────────────────────────────────────────────────────┤
│               │                                                     │
│ ━━Electric━━  │   ALTERNATOR                                        │
│               │   Status:      Idle                                 │
│   Water       │   Power:       0W                                   │
│               │                                                     │
│   Climate     │   INVERTER                                          │
│               │   Status:      OFF                                  │
│   Status      │   Load:        0W                                   │
│               │                                                     │
│   Power       │   BATTERY DETAILS                                   │
│               │   Temperature: 22°C                                 │
│               │   Time to Full: 3h 24min                            │
│               │   Cycles:      147                                  │
│               │                                                     │
│               │                                   [ ← Back ]        │
└───────────────┴─────────────────────────────────────────────────────┘
```

---

## Status Page 1 - Overview (Page 7)

```
┌─────────────────────────────────────────────────────────────────────┐
│                                                                1/2  │
│  ⚠️ MASTER WARNING                                                  │
│                                                                     │
├───────────────┬─────────────────────────────────────────────────────┤
│               │                                                     │
│   Electric    │   SICHERUNGEN (FUSES)                               │
│               │                                                     │
│   Water       │   🔴 Sich.1 Main      🟢 Sich.2 Lights             │
│               │   🟢 Sich.3 Water     🟢 Sich.4 Heater             │
│   Climate     │   🔴 Sich.5 12V Aux   🟢 Sich.6 Fridge             │
│               │   🟢 Sich.7 Pump      🟢 Sich.8 Outlet             │
│ ━━Status━━    │   🟢 Sich.9 Climate   🟢 Sich.10 USB              │
│               │                                                     │
│   Power       │   ELECTRICAL STATUS                                 │
│               │   Battery:    12.8V (78%) 🟢                        │
│               │   Solar:      245W        🟢                        │
│               │   Shore:      Disconnected                          │
│               │                                                     │
│               │                                   [ Next Page → ]   │
└───────────────┴─────────────────────────────────────────────────────┘
```

---

## Status Page 2 - Tanks (Page 8)

```
┌─────────────────────────────────────────────────────────────────────┐
│                                                                2/2  │
│  ⚠️ MASTER WARNING                                                  │
│                                                                     │
├───────────────┬─────────────────────────────────────────────────────┤
│               │                                                     │
│   Electric    │   TANK LEVELS                                       │
│               │                                                     │
│   Water       │   ┌─────────────────────────────────┐               │
│               │   │ Fresh Water:  45L (60%)  🟢    │               │
│   Climate     │   └─────────────────────────────────┘               │
│               │                                                     │
│ ━━Status━━    │   ┌─────────────────────────────────┐               │
│               │   │ Gray Water:   28L (40%)  🟢    │               │
│   Power       │   └─────────────────────────────────┘               │
│               │                                                     │
│               │   ┌─────────────────────────────────┐               │
│               │   │ Black Water:  52L (87%)  🔴    │               │
│               │   └─────────────────────────────────┘               │
│               │                                                     │
│               │   ┌─────────────────────────────────┐               │
│               │   │ LPG Gas:      3.2kg (40%) 🟢   │               │
│               │   └─────────────────────────────────┘               │
│               │                                                     │
│               │                                   [ ← Back ]        │
└───────────────┴─────────────────────────────────────────────────────┘
```

---

## Master Warning State (Lauftext Beispiele)

### Normal State (Grün)
```
┌─────────────────────────────────────────────────────────────────────┐
│  ✓ ALL SYSTEMS NORMAL                                              │
└─────────────────────────────────────────────────────────────────────┘
```

### Master Caution (Orange)
```
┌─────────────────────────────────────────────────────────────────────┐
│  ⚡ MASTER CAUTION                                                  │
└─────────────────────────────────────────────────────────────────────┘
```

### Master Warning (Rot)
```
┌─────────────────────────────────────────────────────────────────────┐
│  ⚠️ MASTER WARNING                                                  │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Navigation Flow

```
                          HOME (Page 0)
                               │
        ┌──────────────┬───────┼───────┬──────────────┐
        │              │       │       │              │
    ELECTRIC        WATER   CLIMATE  STATUS        POWER
   (Pages 1-2)   (Pages 3-4) (5-6)  (Pages 7-8)  (Pages 9-10)
        │              │       │       │              │
        ↓              ↓       ↓       ↓              ↓
    Electric_1     Water_1  Climate_1 Status_1    Power_1
        │              │       │       │              │
        ↓              ↓       ↓       ↓              ↓
    Electric_2     Water_2  Climate_2 Status_2    Power_2
        │              │       │       │              │
        └──────────────┴───────┴───────┴──────────────┘
                          │
                     Zurück zu 1
                   (oder zu anderer
                      Sektion)
```

---

## Button States

### Inactive Menu Button
```
┌───────────────┐
│               │
│   Electric    │  ← Weiß (65535)
│               │
└───────────────┘
```

### Active Menu Button (Aktuelle Sektion)
```
┌───────────────┐
│               │
│ ━━Electric━━  │  ← Grün (2016) + Underline
│               │
└───────────────┘
```

---

## Color Reference (in Mockups)

| Symbol | Farbe | Bedeutung | Hex | Decimal |
|--------|-------|-----------|-----|---------|
| 🟢 | Grün | OK / Normal | #07E0 | 2016 |
| 🟠 | Orange | Caution / Warnung | #FC00 | 64512 |
| 🔴 | Rot | Warning / Kritisch | #F800 | 63488 |
| ⚪ | Weiß | Text / Inaktiv | #FFFF | 65535 |
| ━━ | Underline | Aktive Sektion | - | - |

---

## Layout Grid (800x480)

```
    0        150                                                   800
    ├─────────┼────────────────────────────────────────────────────┤
    │         │                                                    │  0
    │  MENU   │              HEADER (Alert Text)                   │
    │         │                                                    │  50
    ├─────────┼────────────────────────────────────────────────────┤
    │         │                                                    │
    │         │                                                    │
    │ Button  │                                                    │
    │ Button  │                                                    │
    │ Button  │            CONTENT AREA                            │
    │ Button  │            (650 x 430 px)                          │
    │ Button  │                                                    │
    │         │                                                    │
    │         │                                                    │
    │         │                                                    │
    │         │                                                    │  480
    └─────────┴────────────────────────────────────────────────────┘

Menu Width:    150px
Content Width: 650px
Header Height: 50px
Content Height: 430px
```

---

## Touch Areas

```
Menu Buttons: 150x80 px (gut erreichbar)
Next Button:  120x50 px (rechts unten)
Alert Text:   800x50 px (oben, klickbar für Status)
```

---

## Anmerkungen

1. **Transparentes Design**: Alle Komponenten haben `bco=65535` (transparent)
2. **Scrolling Text**: Lauftext scrollt nur wenn Text > Display-Breite
3. **Farbwechsel**: Dynamisch via ESPHome (pco ändern)
4. **Symbole**: Unicode funktioniert in Nextion (✓ ⚠️ ⚡ 🟢 🔴)
5. **Seiten-Zähler**: Immer rechts oben (1/2, 2/2)
6. **Navigation**: Links = Sektionen, Rechts/Center = Seiten-Navigation

---

## Für dein Nextion-Projekt

1. Nutze diese Mockups als Referenz
2. Erstelle Komponenten an den gezeigten Positionen
3. Benenne Komponenten wie in ESPHome-Configs
4. Teste Navigation-Flow
5. Passe Content-Bereich für eigene Bedürfnisse an
