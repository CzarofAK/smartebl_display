# Nextion Page Structure - Detaillierte Dokumentation

Komplette Referenz aller Pages, Komponenten, Events und Nextion-Code.

## 📋 Seitenübersicht

| Page ID | Name | Funktion | Sub-Pages |
|---------|------|----------|-----------|
| 0 | Home | Hauptmenü mit Navigation | - |
| 1 | Electric_1 | Elektrik Seite 1 | Electric_2 |
| 2 | Electric_2 | Elektrik Seite 2 | - |
| 3 | Water_1 | Wasser Seite 1 | Water_2 |
| 4 | Water_2 | Wasser Seite 2 | - |
| 5 | Climate_1 | Klima Seite 1 | Climate_2 |
| 6 | Climate_2 | Klima Seite 2 | - |
| 7 | Status_1 | Status-Übersicht 1 | Status_2 |
| 8 | Status_2 | Status-Übersicht 2 | - |
| 9 | Power_1 | Energie Seite 1 | Power_2 |
| 10 | Power_2 | Energie Seite 2 | - |

---

## 📄 Page 0: Home

### Komponenten

#### txt_alert (Scrolling Text)
- **Component ID:** `xstr` / ID: `1`
- **Position:** x=0, y=0, w=800, h=50
- **Font:** 24pt Bold
- **Background:** Transparent (`bco=0`)
- **Text Color:** Grün (`pco=2016`)
- **Scrolling:** 
  - Direction: `dir=0` (left to right)
  - Speed: `tim=200`
- **Initial Text:** `✓ ALL SYSTEMS NORMAL`

**Touch Events:**
```c
// Touch Release Event
page Status_1
```

**ESPHome Updates:**
```cpp
// Text ändern
id(nextion_display).set_component_text("txt_alert", "⚠️ MASTER WARNING");

// Farbe ändern
id(nextion_display).set_component_value("txt_alert.pco", 63488);  // Rot

// Hintergrund ändern (falls gewünscht)
id(nextion_display).set_component_value("txt_alert.bco", 0);  // Transparent
```

---

#### btn_electric (Button)
- **Component ID:** `b0`
- **Position:** x=0, y=60, w=150, h=80
- **Text:** `Electric`
- **Font:** 20pt
- **Background:** Transparent (`bco=0`)
- **Text Color:** Weiß (`pco=65535`)

**Touch Events:**
```c
// Touch Release Event
page Electric_1
```

---

#### btn_water (Button)
- **Component ID:** `b1`
- **Position:** x=0, y=150, w=150, h=80
- **Text:** `Water`

**Touch Events:**
```c
page Water_1
```

---

#### btn_climate (Button)
- **Component ID:** `b2`
- **Position:** x=0, y=240, w=150, h=80
- **Text:** `Climate`

**Touch Events:**
```c
page Climate_1
```

---

#### btn_status (Button)
- **Component ID:** `b3`
- **Position:** x=0, y=330, w=150, h=80
- **Text:** `Status`

**Touch Events:**
```c
page Status_1
```

---

#### btn_power (Button)
- **Component ID:** `b4`
- **Position:** x=0, y=420, w=150, h=80
- **Text:** `Power`

**Touch Events:**
```c
page Power_1
```

---

## 📄 Page 1: Electric_1

### Page Events

#### Preinit Event
```c
// Menü-Button Highlighting
btn_electric.pco=2016   // Grün (aktiv)
btn_water.pco=65535     // Weiß (inaktiv)
btn_climate.pco=65535
btn_status.pco=65535
btn_power.pco=65535
```

### Komponenten

#### txt_page_counter (Text)
- **Position:** x=700, y=10, w=80, h=30
- **Text:** `1/2`
- **Font:** 16pt
- **Alignment:** Center
- **Text Color:** Weiß

---

#### Menü-Buttons (gleiche wie Home)

**btn_electric Touch Event:**
```c
page Electric_2
```

**btn_water Touch Event:**
```c
page Water_1
```

**btn_climate Touch Event:**
```c
page Climate_1
```

**btn_status Touch Event:**
```c
page Status_1
```

**btn_power Touch Event:**
```c
page Power_1
```

---

#### Content-Bereich (Beispiel-Komponenten)

**txt_battery_voltage (Text)**
- **Name:** `txt_battery_voltage`
- **Position:** x=200, y=100, w=250, h=40
- **Initial Text:** `Battery: 12.8V`
- **Font:** 20pt
- **Text Color:** Weiß

**ESPHome Update:**
```cpp
float voltage = id(batterie_spannung).state;
std::string text = "Battery: " + to_string(voltage) + "V";
id(nextion_display).set_component_text("txt_battery_voltage", text.c_str());

// Farbe basierend auf Spannung
int color = voltage < 11.5 ? 63488 : (voltage < 12.2 ? 64512 : 2016);
id(nextion_display).set_component_value("txt_battery_voltage.pco", color);
```

---

**txt_battery_soc (Text)**
- **Name:** `txt_battery_soc`
- **Position:** x=200, y=150, w=250, h=40
- **Initial Text:** `SOC: 78%`

**ESPHome Update:**
```cpp
int soc = (int)id(batterie_soc).state;
it.set_component_text("txt_battery_soc", (to_string(soc) + "%").c_str());
int color = soc < 20 ? 63488 : (soc < 40 ? 64512 : 2016);
it.set_component_value("txt_battery_soc.pco", color);
```

---

**sich1 bis sich18 (Text Komponenten)**
- **Name:** `sich1`, `sich2`, ..., `sich18`
- **Position:** Grid-Layout im Content-Bereich
- **Initial Text:** `Sich.1 OK`
- **Font:** 16pt

**ESPHome Update:**
```cpp
// Sicherung 1
if (id(sicherung_1).state) {
  it.set_component_text("sich1", "Sich.1 FAULT");
  it.set_component_value("sich1.pco", 63488);  // Rot
} else {
  it.set_component_text("sich1", "Sich.1 OK");
  it.set_component_value("sich1.pco", 2016);  // Grün
}

// Für alle 18 Sicherungen wiederholen
```

---

## 📄 Page 2: Electric_2

Identisch zu Electric_1, außer:

### Page Events

#### Preinit Event
```c
// Gleiche wie Electric_1
btn_electric.pco=2016   // Immer noch Grün
btn_water.pco=65535
btn_climate.pco=65535
btn_status.pco=65535
btn_power.pco=65535
```

### Unterschiede

**txt_page_counter:**
```c
txt_page_counter.txt="2/2"
```

**btn_electric Touch Event:**
```c
page Electric_1  // Zurück zur ersten Seite
```

---

## 📄 Page 3-10: Weitere Sektionen

Alle weiteren Pages folgen dem gleichen Muster wie Electric_1/2:

### Water_1 / Water_2
- Preinit Event: `btn_water.pco=2016`
- Touch Events: Navigieren zwischen Water_1 ↔ Water_2

### Climate_1 / Climate_2
- Preinit Event: `btn_climate.pco=2016`

### Status_1 / Status_2
- Preinit Event: `btn_status.pco=2016`
- **SPEZIAL:** Umfangreiche Alarm-Übersicht (siehe unten)

### Power_1 / Power_2
- Preinit Event: `btn_power.pco=2016`

---

## 📄 Status_1 - Spezial-Layout

### Erweiterte Komponenten

#### txt_alarm_summary (Text)
- **Position:** x=160, y=10, w=500, h=40
- **Font:** 24pt Bold
- **Initial Text:** `✓ ALL SYSTEMS OK`
- **Text Color:** Grün

**ESPHome Update:**
```cpp
int w_count = id(alarm_count_warning);
int c_count = id(alarm_count_caution);

std::string summary;
int color;

if (w_count > 0) {
  summary = "⚠️ " + to_string(w_count) + " WARNINGS";
  color = 63488;  // Rot
} else if (c_count > 0) {
  summary = "⚡ " + to_string(c_count) + " CAUTIONS";
  color = 64512;  // Orange
} else {
  summary = "✓ ALL SYSTEMS OK";
  color = 2016;  // Grün
}

it.set_component_text("txt_alarm_summary", summary.c_str());
it.set_component_value("txt_alarm_summary.pco", color);
```

---

#### Sicherungs-Grid (sich1 bis sich18)

**Layout-Beispiel:**
```
Row 1: sich1  sich2  sich3  sich4  sich5  sich6
Row 2: sich7  sich8  sich9  sich10 sich11 sich12
Row 3: sich13 sich14 sich15 sich16 sich17 sich18
```

- **Position Start:** x=160, y=60
- **Spacing:** 120px horizontal, 40px vertikal
- **Komponenten-Größe:** 110x30px

**ESPHome Update (Loop für alle 18):**
```cpp
// Beispiel mit Array/Vector
const char* fuse_names[] = {"Main", "Lights", "Water", "Heater", ...};

for (int i = 1; i <= 18; i++) {
  std::string comp = "sich" + to_string(i);
  bool fault = false;
  
  // Prüfe jeweilige Sicherung
  if (i == 1) fault = id(sicherung_1).state;
  if (i == 2) fault = id(sicherung_2).state;
  // ... etc
  
  int color = fault ? 63488 : 2016;  // Rot : Grün
  std::string text = "S" + to_string(i) + " " + std::string(fuse_names[i-1]);
  
  it.set_component_text(comp.c_str(), text.c_str());
  it.set_component_value((comp + ".pco").c_str(), color);
}
```

---

#### Tank-Anzeigen

**txt_fresh (Text)**
- **Position:** x=160, y=200, w=300, h=30
- **Text:** `Fresh: 85L (60%)`

**txt_gray (Text)**
- **Position:** x=470, y=200, w=300, h=30
- **Text:** `Gray: 48L (70%)`

**txt_black (Text)**
- **Position:** x=160, y=240, w=300, h=30
- **Text:** `Black: 18L (90%)`

**txt_gas (Text)**
- **Position:** x=470, y=240, w=300, h=30
- **Text:** `LPG: 8.5kg (85%)`

---

## 🔧 Nextion Code-Snippets

### Globale Variablen (Optional)

Im Nextion Editor → **Program.s** (nicht Page Event):

```c
// Aktuelle Sektion (0=Home, 1=Electric, 2=Water, etc.)
int currentSection=0

// Seiten-Index innerhalb Sektion
int currentPage=0

// Max Pages pro Sektion (kann dynamisch sein)
int maxPages=2
```

### Dynamische Seitenzahl

Statt manuell "1/2" auf jeder Page, könnte man nutzen:

**Electric_1 Preinit:**
```c
currentSection=1
currentPage=1
maxPages=2
txt_page_counter.txt=currentPage + "/" + maxPages
```

**ABER:** Nextion unterstützt keine String-Konkatenation direkt!
→ Einfacher: Manuell "1/2" setzen auf jeder Page.

---

## 📡 UART-Befehle (ESPHome → Nextion)

### Text setzen
```cpp
it.set_component_text("txt_alert", "Neuer Text");
```

**Nextion Befehl (raw):**
```
txt_alert.txt="Neuer Text"
```

### Farbe setzen
```cpp
it.set_component_value("txt_alert.pco", 63488);  // Rot
```

**Nextion Befehl (raw):**
```
txt_alert.pco=63488
```

### Wert setzen (Number)
```cpp
it.set_component_value("n0", 1234);
```

**Nextion Befehl (raw):**
```
n0.val=1234
```

### Page wechseln
```cpp
it.goto_page("Electric_1");
```

**Nextion Befehl (raw):**
```
page Electric_1
```

---

## 🎨 Design Best Practices

### 1. Konsistente Komponenten-Namen

Nutze Präfixe:
- `txt_` für Text-Komponenten
- `btn_` für Buttons
- `n_` für Number-Komponenten
- `bar_` für Progress Bars
- `sich` für Sicherungen (ohne Unterstrich wegen Index)

### 2. Farb-Konventionen einhalten

```c
// Grün = OK/Normal
pco=2016

// Orange = Warnung
pco=64512

// Rot = Alarm/Fehler
pco=63488

// Grau = Inaktiv/Aus
pco=50712

// Weiß = Standard-Text
pco=65535

// Blau = Aktiv/Läuft
pco=31
```

### 3. Transparenz für cleanes Design

Alle Buttons und Texte:
```c
bco=0  // Hintergrund transparent (auf schwarzem Hintergrund)
```

### 4. Touch Event Best Practices

**Bevorzuge Touch Release über Touch Press:**
```c
// GUT: Touch Release Event
page Electric_1

// VERMEIDEN: Touch Press Event
// (kann zu versehentlichen Klicks führen)
```

---

## 🐛 Debugging

### Nextion Debug Output aktivieren

Im Nextion Editor:
1. **Page → Program.s**
2. Am Anfang hinzufügen:
```c
// Debug-Output an UART
bkcmd=3
```

Das sendet Status-Codes zurück, die ESPHome empfangen kann.

### ESPHome Debug Logging

```yaml
logger:
  level: DEBUG
  logs:
    nextion: DEBUG
```

Zeigt alle UART-Kommunikation im Log.

---

## 📚 Komponenten-Referenz

### Text (t / xstr)
- `txt`: Text-Inhalt
- `pco`: Text-Farbe
- `bco`: Hintergrund-Farbe
- `font`: Font-ID (0, 1, 2, ...)
- `xcen` / `ycen`: Zentrierung (0=aus, 1=an)
- `pw`: Passwort-Modus (für xstr)

### Number (n)
- `val`: Zahlenwert
- `vvs0`: Vorzeichen anzeigen (0=nein, 1=ja)
- `vvs1`: Dezimalstellen (0-3)
- `lenth`: Maximale Stellen

### Button (b)
- `txt`: Button-Text
- `pco` / `pco2`: Text-Farbe (normal / gedrückt)
- `bco` / `bco2`: Hintergrund (normal / gedrückt)
- `font`: Font-ID

### Progress Bar (j)
- `val`: Aktueller Wert (0-100)
- `pco`: Fortschritts-Farbe
- `bco`: Hintergrund-Farbe

---

## ✅ Checkliste pro Page

- [ ] Page erstellt mit eindeutiger ID
- [ ] Menü-Buttons von Home kopiert
- [ ] Touch Events auf allen Buttons gesetzt
- [ ] Preinit Event für Button-Highlighting gesetzt
- [ ] Seitenzähler eingefügt und Text gesetzt
- [ ] Content-Komponenten mit eindeutigen Namen
- [ ] Alle Komponenten transparent (bco=0)
- [ ] Farben nach Konvention gesetzt
- [ ] Test: Navigation funktioniert
- [ ] Test: ESPHome kann Werte aktualisieren

---

**Weiter zu:** [`customization.md`](../docs/customization.md) für Anpassung an eigene Sensoren!
