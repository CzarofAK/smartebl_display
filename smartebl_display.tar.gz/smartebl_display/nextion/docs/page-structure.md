# Nextion Page Structure

**Komplette Schritt-für-Schritt Anleitung für das Nextion Display**

## Display Spezifikationen

- **Modell**: NX8048P070 (7" Enhanced)
- **Resolution**: 800 x 480 pixels
- **Orientation**: Horizontal
- **Baud Rate**: 115200

---

## Seitenübersicht

| Page ID | Name | Beschreibung |
|---------|------|--------------|
| 0 | Home | Hauptmenü mit 5 Sektions-Buttons |
| 1-2 | Electric_1, Electric_2 | Elektrische Systeme |
| 3-4 | Water_1, Water_2 | Wasser-Systeme |
| 5-6 | Climate_1, Climate_2 | Klima & Heizung |
| 7-8 | Status_1, Status_2 | System-Status & Alarme |
| 9-10 | Power_1, Power_2 | Energie & Batterien |

---

## Globale Variablen

**Program.s → Variable hinzufügen:**

```c
// Speichert aktuelle Sektion (0=Home, 1=Electric, 2=Water, 3=Climate, 4=Status, 5=Power)
int currentSection=0

// Speichert Seiten-Index innerhalb Sektion (0=erste, 1=zweite)
int currentPage=0

// Anzahl Seiten pro Sektion (für dynamische Berechnung)
int electricPages=2
int waterPages=2
int climatePages=2
int statusPages=2
int powerPages=2
```

---

## Farbdefinitionen

| Farbe | Hex | Decimal | Verwendung |
|-------|-----|---------|------------|
| Rot | `#F800` | 63488 | Master WARNING |
| Orange | `#FC00` | 64512 | Master CAUTION |
| Grün | `#07E0` | 2016 | Normal / Aktiv |
| Grau | `#C618` | 50712 | Inaktiv |
| Weiß | `#FFFF` | 65535 | Text / Transparent |

---

## Page 0: Home (Hauptmenü)

### Komponenten

#### 1. Lauftext - Master Warning/Caution

- **Typ**: Scrolling Text
- **Name**: `txt_alert`
- **Position**: x=0, y=0
- **Größe**: w=800, h=50
- **Font**: Font 3 (24pt)
- **Eigenschaften**:
  - `bco`: 65535 (transparent)
  - `pco`: 2016 (grün, wird dynamisch geändert)
  - `pco2`: 65535 (transparent)
  - `dir`: 0 (left-to-right)
  - `dis`: 1 (scrolling aktiviert)
  - `tim`: 50 (scroll speed)
  - `xcen`: 1 (zentriert)
  - `ycen`: 1 (zentriert vertikal)

#### 2. Menu Buttons (5x vertikal)

**Button: Electric**
- **Typ**: Button
- **Name**: `btn_electric`
- **Position**: x=0, y=60
- **Größe**: w=150, h=80
- **Text**: "Electric"
- **Font**: Font 2 (20pt)
- **Eigenschaften**:
  - `bco`: 65535 (transparent)
  - `pco`: 65535 (weiß)
  - `pco2`: 65535 (transparent)
  - `txt`: "Electric"

**Touch Release Event:**
```c
currentSection=1
currentPage=0
page Electric_1
```

---

**Button: Water**
- **Name**: `btn_water`
- **Position**: x=0, y=150
- **Größe**: w=150, h=80
- **Text**: "Water"

**Touch Release Event:**
```c
currentSection=2
currentPage=0
page Water_1
```

---

**Button: Climate**
- **Name**: `btn_climate`
- **Position**: x=0, y=240
- **Größe**: w=150, h=80
- **Text**: "Climate"

**Touch Release Event:**
```c
currentSection=3
currentPage=0
page Climate_1
```

---

**Button: Status**
- **Name**: `btn_status`
- **Position**: x=0, y=330
- **Größe**: w=150, h=80
- **Text**: "Status"

**Touch Release Event:**
```c
currentSection=4
currentPage=0
page Status_1
```

---

**Button: Power**
- **Name**: `btn_power`
- **Position**: x=0, y=420
- **Größe**: w=150, h=80
- **Text**: "Power"

**Touch Release Event:**
```c
currentSection=5
currentPage=0
page Power_1
```

---

### Page Preinit Event (Home)

```c
// Setze alle Buttons auf Standard-Farbe
btn_electric.pco=65535
btn_water.pco=65535
btn_climate.pco=65535
btn_status.pco=65535
btn_power.pco=65535

// Reset Section Tracking
currentSection=0
currentPage=0
```

---

## Pages 1-2: Electric Section

### Page 1: Electric_1

#### Komponenten

**1. Lauftext** (gleich wie Home - kopieren)
- Name: `txt_alert`

**2. Seitenzähler**
- **Typ**: Text
- **Name**: `txt_page_counter`
- **Position**: x=700, y=10
- **Größe**: w=80, h=30
- **Font**: Font 1 (16pt)
- **Text**: "1/2"
- **Eigenschaften**:
  - `bco`: 65535 (transparent)
  - `pco`: 65535 (weiß)
  - `txt`: "1/2"
  - `xcen`: 2 (rechts)
  - `ycen`: 1 (zentriert)

**3. Menu Buttons** (gleich wie Home - kopieren)
- `btn_electric`, `btn_water`, `btn_climate`, `btn_status`, `btn_power`

**Touch Events für Menu Buttons:**

```c
// btn_electric - Nächste Electric Page
currentPage++
if(currentPage>=electricPages)
{
  currentPage=0
}
page Electric_2

// btn_water - Zu Water Sektion
currentSection=2
currentPage=0
page Water_1

// btn_climate - Zu Climate Sektion
currentSection=3
currentPage=0
page Climate_1

// btn_status - Zu Status Sektion
currentSection=4
currentPage=0
page Status_1

// btn_power - Zu Power Sektion
currentSection=5
currentPage=0
page Power_1
```

**4. Next Page Button**
- **Typ**: Button
- **Name**: `btn_next`
- **Position**: x=650, y=400
- **Größe**: w=120, h=50
- **Text**: "Next →"

**Touch Release Event:**
```c
currentPage=1
page Electric_2
```

**5. Content Area** (Platzhalter für eigene Komponenten)
- Hier kommen deine individuellen Elemente rein:
  - Text für Batterie-Spannung
  - Number für Strom
  - Progress Bar für SOC
  - etc.

---

#### Page Preinit Event (Electric_1)

```c
// Highlight aktiven Button
btn_electric.pco=2016  // Grün
btn_water.pco=65535    // Weiß
btn_climate.pco=65535
btn_status.pco=65535
btn_power.pco=65535

// Update Seitenzähler
txt_page_counter.txt="1/2"

// Update Tracking
currentSection=1
currentPage=0
```

---

### Page 2: Electric_2

**Identischer Aufbau wie Electric_1, aber:**

**Touch Events anpassen:**

```c
// btn_electric - Zurück zu Electric_1
currentPage=0
page Electric_1

// btn_next - Zurück zu Electric_1 oder weiter (falls 3. Seite)
currentPage=0
page Electric_1
```

**Page Preinit Event:**
```c
// Gleich wie Electric_1, nur:
txt_page_counter.txt="2/2"
currentPage=1
```

---

## Pages 3-4: Water Section

**Gleicher Aufbau wie Electric Section:**

1. Kopiere Electric_1 zu Water_1
2. Benenne um:
   - Page Name: Water_1
   - Alle Page-IDs anpassen
3. Touch Events anpassen:
   ```c
   // btn_water Touch Event:
   page Water_2
   ```
4. Page Preinit:
   ```c
   btn_water.pco=2016  // Highlight Water
   currentSection=2
   ```

---

## Pages 5-6: Climate Section

Gleicher Prozess wie Water.

---

## Pages 7-8: Status Section

### Besonderheit: Status_1 zeigt alle Alarme

#### Zusätzliche Komponenten für Status_1

**Sicherungs-Anzeige (18 Stück)**

Für jede Sicherung:
- **Typ**: Text
- **Name**: `sich_1`, `sich_2`, ..., `sich_18`
- **Position**: Grid-Layout (3 Spalten x 6 Zeilen)
  - sich_1: x=170, y=70, w=180, h=40
  - sich_2: x=370, y=70, w=180, h=40
  - sich_3: x=570, y=70, w=180, h=40
  - sich_4: x=170, y=120, w=180, h=40
  - ...etc
- **Font**: Font 1 (16pt)
- **Text**: "Sich.1 Main"
- **Eigenschaften**:
  - `bco`: 65535 (transparent)
  - `pco`: 2016 (grün, wird dynamisch zu rot bei Alarm)
  - `xcen`: 0 (links)

**Tank-Level Anzeige**

```
Position unter Sicherungen:

Fresh Water:  [Tank-Icon] 45L (60%) 🟢
Gray Water:   [Tank-Icon] 28L (40%) 🟢
Black Water:  [Tank-Icon] 12L (20%) 🔴
LPG:          [Tank-Icon] 3.2kg (40%) 🟢
```

Für jeden Tank:
- **Typ**: Text + Number
- **Name**: `tank_fresh`, `tank_fresh_pct`
- Dynamische Farbänderung via ESPHome

---

## Pages 9-10: Power Section

Gleicher Prozess wie andere Sektionen.

---

## Best Practices

### 1. Wiederverwendbare Komponenten

**Workflow:**
1. Erstelle Home-Page komplett
2. Kopiere Lauftext + 5 Buttons
3. Füge auf jeder Unterseite ein
4. Passe nur Touch Events an

### 2. Konsistente Namen

```
Seiten:     Electric_1, Electric_2, Water_1, ...
Buttons:    btn_electric, btn_water, btn_next
Text:       txt_alert, txt_page_counter
Sicherung:  sich_1, sich_2, ...
Tanks:      tank_fresh, tank_gray, ...
```

### 3. Transparenz für alle Komponenten

Für **jeden** Button/Text:
```
bco=65535   (Background transparent)
pco=65535   (Text weiß standard)
pco2=65535  (Press color transparent)
```

### 4. Touch Events Struktur

```c
// Immer:
currentSection=X  // Tracking
currentPage=Y     // Tracking
page PageName     // Navigation
```

### 5. Fonts

- **Font 0**: 12pt - Klein, Details
- **Font 1**: 16pt - Standard Text
- **Font 2**: 20pt - Buttons
- **Font 3**: 24pt - Lauftext
- **Font 4**: 32pt - Große Werte

---

## Testing Checklist

- [ ] Alle Buttons führen zur richtigen Seite
- [ ] Seitenzähler zeigt korrekte Werte
- [ ] Transparenz funktioniert (kein Hintergrund sichtbar)
- [ ] Lauftext scrollt bei langem Text
- [ ] Navigation zwischen Sektionen funktioniert
- [ ] Navigation innerhalb Sektion funktioniert
- [ ] Page Preinit Events setzen richtige Button-Farben
- [ ] UART Kommunikation funktioniert (Testbefehl: `txt_alert.txt="TEST"`)

---

## Tipps & Tricks

### Schnelles Kopieren von Komponenten

1. Rechtsklick auf Komponente → Copy
2. Rechtsklick auf Page → Paste
3. Position/Name anpassen

### Bulk-Editing mit Nextion

Leider nicht möglich - jede Komponente manuell anpassen.

**Workaround**: Erstelle erste Page perfekt, dann kopiere gesamte Page als Template.

### HMI-Datei Backup

Nextion Editor speichert nur .HMI (Binary).
**Keine Versionskontrolle möglich!**

→ Regelmäßig Backups erstellen:
```
Project_v1.0.HMI
Project_v1.1.HMI
Project_WORKING.HMI
```

---

## Troubleshooting

### "Component not found" Error

- **Ursache**: Name falsch geschrieben oder Komponente existiert nicht auf aktueller Page
- **Lösung**: Prüfe exakte Schreibweise (case-sensitive!)

### Scrolling funktioniert nicht

- **Ursache**: `dis=0` oder Text zu kurz
- **Lösung**: `dis=1` setzen, Text länger als Component-Width

### Button funktioniert nicht

- **Ursache**: Touch Event nicht gesetzt oder Page-ID falsch
- **Lösung**: Prüfe Touch Release Event, prüfe ob Target-Page existiert

### Transparenz zeigt schwarzen Hintergrund

- **Ursache**: `bco` nicht auf 65535
- **Lösung**: Alle Background-Colors auf 65535 setzen

---

## Nächste Schritte

1. ✅ Nextion Projekt erstellt
2. → ESPHome Config erstellen (siehe `/esphome/display-base.yaml`)
3. → Master Warning/Caution Logik implementieren
4. → Eigene Sensoren hinzufügen

Siehe [Design Guide](design-guide.md) für weitere Details!
