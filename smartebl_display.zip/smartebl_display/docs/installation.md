# Installation Guide

**Schritt-für-Schritt Anleitung für SmartEBL Display**

---

## Voraussetzungen

### Hardware
- ✅ **ESP32** Development Board (z.B. ESP32-DevKitC, ESP32-WROOM-32)
- ✅ **Nextion Display** 7" (NX8048P070 Enhanced empfohlen)
- ✅ Jumper-Kabel (Female-Female)
- ✅ 5V Stromversorgung (min. 1A für Display)
- ✅ microSD-Karte (optional, für Nextion Flash)

### Software
- ✅ **Nextion Editor** ([Download](https://nextion.tech/nextion-editor/))
- ✅ **ESPHome** installiert ([Anleitung](https://esphome.io/guides/installing_esphome.html))
- ✅ **Home Assistant** (optional, aber empfohlen)
- ✅ Text-Editor (VS Code, Notepad++, etc.)

---

## Teil 1: Hardware-Verkabelung

### ESP32 ↔ Nextion Display

```
ESP32              Nextion Display
─────────────      ───────────────────
GPIO17 (TX)   -->  RX (Gelb)
GPIO16 (RX)   <--  TX (Blau)
GND           ---  GND (Schwarz)
5V            ---  +5V (Rot)
```

**⚠️ WICHTIG:**
- ESP32 TX → Nextion RX
- ESP32 RX → Nextion TX
- Verwende **5V** für Nextion (nicht 3.3V!)
- GND gemeinsam verbinden

### Pin-Anpassung

Falls du andere GPIO-Pins nutzt:

```yaml
# In display-base.yaml oder main.yaml
uart:
  tx_pin: GPIO17  # ← Dein TX Pin
  rx_pin: GPIO16  # ← Dein RX Pin
```

---

## Teil 2: Nextion Display vorbereiten

### 2.1 Nextion Editor installieren

1. Download von [nextion.tech](https://nextion.tech/nextion-editor/)
2. Installieren und öffnen
3. Lizenzvereinbarung akzeptieren

### 2.2 Projekt erstellen

1. **File → New Nextion Project**
2. **Display auswählen**:
   - Model: **NX8048P070** (7" Enhanced)
   - Series: Enhanced
   - Resolution: 800x480
3. **Orientation**: Horizontal
4. **OK klicken**

### 2.3 Display aufbauen

Folge der detaillierten Anleitung:

👉 **[nextion/docs/page-structure.md](../nextion/docs/page-structure.md)**

**Quick-Checklist:**
- [ ] 11 Pages erstellt (Home + 5 Sektionen x 2)
- [ ] Globale Variablen angelegt
- [ ] Lauftext auf allen Pages
- [ ] 5 Menu-Buttons auf allen Pages
- [ ] Touch Events konfiguriert
- [ ] Page Preinit Events gesetzt
- [ ] Transparenz aktiviert (bco=65535)

### 2.4 Kompilieren & Flashen

#### Methode A: microSD-Karte (empfohlen)

1. **File → TFT File Output**
2. Wähle Output-Ordner
3. **Compile**
4. Kopiere `.tft` File auf microSD (FAT32)
5. MicroSD in Nextion einlegen
6. Nextion mit Strom versorgen
7. Warte bis Flash abgeschlossen (grüner Balken)
8. MicroSD entfernen, Nextion neu starten

#### Methode B: USB-Serial Upload

1. Nextion via USB-Serial-Adapter an PC anschließen
2. **File → Upload**
3. Wähle COM-Port
4. **Upload** klicken
5. Warte bis abgeschlossen

---

## Teil 3: ESPHome konfigurieren

### 3.1 Projekt-Struktur erstellen

Erstelle folgende Ordnerstruktur:

```
esphome/
├── motorhome-display.yaml    # Haupt-Config
├── secrets.yaml               # Passwörter
├── display-base.yaml          # Von Repo
├── display-alarms.yaml        # Von Repo
└── sections/
    ├── electric.yaml
    ├── status.yaml
    └── ...
```

### 3.2 Files vom Repo holen

**Option A: Git Clone**
```bash
cd ~/esphome
git clone https://github.com/CzarofAK/smartebl_display.git
cd smartebl_display/esphome
```

**Option B: Manueller Download**
1. Gehe zu [GitHub Repo](https://github.com/CzarofAK/smartebl_display)
2. Download ZIP
3. Entpacke nach `~/esphome/`

### 3.3 Haupt-Config erstellen

Erstelle `motorhome-display.yaml`:

```yaml
substitutions:
  device_name: motorhome-display
  friendly_name: "Motorhome Display"

esphome:
  name: ${device_name}
  friendly_name: ${friendly_name}

esp32:
  board: esp32dev  # ← Anpassen für dein Board
  framework:
    type: arduino

# WiFi & API
wifi:
  ssid: !secret wifi_ssid
  password: !secret wifi_password
  ap:
    ssid: "${device_name} Fallback"
    password: !secret ap_password

api:
  encryption:
    key: !secret api_encryption_key

ota:
  - platform: esphome
    password: !secret ota_password

logger:
  level: INFO
  baud_rate: 0  # WICHTIG: UART wird von Nextion genutzt!

# Packages importieren
packages:
  display_base: !include display-base.yaml
  alarms: !include display-alarms.yaml
  electric: !include sections/electric.yaml
  status: !include sections/status.yaml
```

### 3.4 Secrets konfigurieren

Erstelle `secrets.yaml`:

```yaml
# WiFi
wifi_ssid: "Dein_WiFi_SSID"
wifi_password: "DeinWiFiPasswort"

# Fallback AP
ap_password: "FallbackPasswort123"

# API Encryption (32 Zeichen)
api_encryption_key: "dein32zeichenlanger_key_hier1234"

# OTA Password
ota_password: "OTAPasswort123"
```

**Key generieren:**
```bash
# Linux/Mac
openssl rand -base64 32

# Oder in ESPHome Dashboard: Automatically generated
```

### 3.5 Entity IDs anpassen

In `sections/electric.yaml`:

```yaml
sensor:
  - platform: homeassistant
    id: batterie_spannung
    entity_id: sensor.battery_voltage  # ← HIER deine Entity
```

Ersetze **alle** `entity_id` mit deinen Home Assistant Entities!

**Tipp:** Home Assistant → Developer Tools → States → Entity ID kopieren

---

## Teil 4: Flashen & Testen

### 4.1 Erste Flash (USB)

```bash
# Im ESPHome Verzeichnis
esphome run motorhome-display.yaml

# Wähle: USB (erste Flash)
```

Oder via ESPHome Dashboard:
1. Dashboard öffnen
2. **New Device → Continue → Skip**
3. Edit → Config einfügen
4. **Install → Plug into this computer**

### 4.2 WiFi Verbindung testen

Nach erfolgreichem Flash:

```bash
# Logs anzeigen
esphome logs motorhome-display.yaml
```

Du solltest sehen:
```
[INFO] [wifi] WiFi connected!
[INFO] [api] Home Assistant API connected!
[INFO] [main] SmartEBL Display gestartet!
```

### 4.3 Display testen

**Test 1: Alarm System**

In Home Assistant → Developer Tools → Services:

```yaml
service: esphome.motorhome_display_trigger_alarm
```

Oder ändere einen Sensor, um Alarm zu triggern.

**Test 2: Nextion Komponenten**

```bash
# Im ESPHome Log solltest du sehen:
[display] Setting component 'txt_alert' text to '✓ ALL SYSTEMS NORMAL'
```

**Test 3: Touch Events**

Drücke Buttons auf Nextion → Sollte zwischen Pages wechseln

---

## Teil 5: Troubleshooting

### Problem: Display zeigt nichts

**Lösungen:**
- ✅ Prüfe 5V Stromversorgung (min. 1A)
- ✅ Prüfe Nextion wurde geflasht (.tft File)
- ✅ Prüfe UART-Verkabelung (TX ↔ RX richtig?)
- ✅ Teste mit Nextion Debug Tool

### Problem: ESP32 startet nicht

**Lösungen:**
- ✅ Prüfe logger: `baud_rate: 0` gesetzt?
- ✅ Andere UART Pins probieren
- ✅ USB-Kabel wechseln (Datenkabel, nicht nur Ladekabel)

### Problem: "Component not found" im Log

**Lösungen:**
- ✅ Prüfe Nextion Komponenten-Namen (case-sensitive!)
- ✅ Prüfe ob auf richtiger Page (z.B. "bat_volt" nur auf Electric_1)
- ✅ Nextion komplett neu flashen

### Problem: Keine Home Assistant Verbindung

**Lösungen:**
- ✅ Prüfe WiFi-Credentials
- ✅ Prüfe API encryption key
- ✅ ESP32 neu starten
- ✅ Home Assistant Logs prüfen

### Problem: Sensoren zeigen keine Werte

**Lösungen:**
- ✅ Prüfe entity_id korrekt geschrieben
- ✅ Prüfe Sensor existiert in Home Assistant
- ✅ Prüfe Logs: `[homeassistant] Sensor 'xxx' unavailable`

---

## Teil 6: OTA Updates (nach erster Flash)

Nach der ersten USB-Flash kannst du zukünftig **Over-The-Air** updaten:

```bash
# Einfach run, wähle dann WiFi
esphome run motorhome-display.yaml

# Oder im Dashboard: Install → Wirelessly
```

---

## Teil 7: Optimierung

### Display-Helligkeit automatisch anpassen

```yaml
# In main.yaml
time:
  - platform: homeassistant
    on_time:
      - hours: 22
        then:
          - lambda: |-
              id(nextion_display).set_backlight_brightness(0.3);
      - hours: 7
        then:
          - lambda: |-
              id(nextion_display).set_backlight_brightness(0.8);
```

### Alarm-Check Intervall anpassen

```yaml
# In display-alarms.yaml
interval:
  - interval: 2s  # ← Ändern z.B. auf 5s
    then:
      - script.execute: check_alarms
```

### Logging reduzieren

```yaml
# In main.yaml
logger:
  level: WARN  # Nur Warnungen und Errors
```

---

## Nächste Schritte

1. ✅ Installation abgeschlossen
2. → [Customization Guide](customization.md) - Anpassungen
3. → [Page Structure](../nextion/docs/page-structure.md) - Nextion Details
4. → [Design Guide](../nextion/docs/design-guide.md) - Design-Prinzipien

---

## Support

Bei Problemen:
- 📖 [Troubleshooting Guide](troubleshooting.md)
- 🐛 [GitHub Issues](https://github.com/CzarofAK/smartebl_display/issues)
- 💬 [GitHub Discussions](https://github.com/CzarofAK/smartebl_display/discussions)

**Viel Erfolg! 🚀**
