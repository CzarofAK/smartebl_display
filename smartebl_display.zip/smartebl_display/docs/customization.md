# Customization Guide

**Anpassung des SmartEBL Display für deine Bedürfnisse**

---

## Inhaltsverzeichnis

1. [Eigene Sensoren hinzufügen](#eigene-sensoren-hinzufügen)
2. [Neue Sektionen erstellen](#neue-sektionen-erstellen)
3. [Alarm-Schwellwerte anpassen](#alarm-schwellwerte-anpassen)
4. [Layout ändern](#layout-ändern)
5. [Farben anpassen](#farben-anpassen)
6. [Zusätzliche Pages](#zusätzliche-pages)

---

## Eigene Sensoren hinzufügen

### Schritt 1: Sensor in ESPHome definieren

```yaml
# In deiner main.yaml oder einer Sektions-Datei

sensor:
  # Beispiel: Kühlschrank-Temperatur
  - platform: homeassistant
    id: fridge_temperature
    entity_id: sensor.fridge_temp
    internal: false
    on_value:
      then:
        - lambda: |-
            // Update Nextion Display
            char buffer[10];
            snprintf(buffer, sizeof(buffer), "%.1f°C", x);
            id(nextion_display).set_component_text("fridge_temp", buffer);
            
            // Farbe ändern wenn zu warm
            int color = 2016;  // Grün
            if (x > 8.0) {
              color = 64512;  // Orange (zu warm)
            }
            if (x > 10.0) {
              color = 63488;  // Rot (kritisch)
            }
            id(nextion_display).set_component_value("fridge_temp.pco", color);
```

### Schritt 2: Komponente im Nextion erstellen

1. Öffne Nextion-Projekt
2. Gehe zu entsprechender Page (z.B. Climate_1)
3. Füge **Text-Komponente** hinzu:
   - Name: `fridge_temp`
   - Position: x=200, y=150
   - Größe: w=200, h=40
   - Font: Font 2
   - Text: "0.0°C" (Platzhalter)
   - `bco`: 65535 (transparent)
   - `pco`: 2016 (grün)
4. Speichern & kompilieren
5. Auf Display flashen

### Schritt 3: Testen

```bash
esphome run motorhome-display.yaml
```

Im Log solltest du sehen:
```
[homeassistant] 'fridge_temperature': Got state 5.2
[display] Setting component 'fridge_temp' text to '5.2°C'
```

---

## Neue Sektionen erstellen

### Beispiel: "Lighting" Sektion hinzufügen

#### 1. Nextion Pages erstellen

Aktuell: Pages 0-10 belegt

Neue Pages:
- Page 11: Lighting_1
- Page 12: Lighting_2

**Im Nextion Editor:**

1. **Rechtsklick auf Page-Liste → Add Page**
2. Name: `Lighting_1`
3. Page ID: 11
4. **Komponenten kopieren** von Electric_1:
   - Lauftext
   - 5 Menu-Buttons
   - Seitenzähler
   - Next-Button

**Menu-Button auf Home (Page 0) hinzufügen:**

1. Kopiere `btn_power`
2. Benenne um zu `btn_lighting`
3. Position: x=0, y=510 (unter Power)
4. Text: "Lighting"
5. Touch Release Event:
   ```c
   currentSection=6
   currentPage=0
   page Lighting_1
   ```

**Touch Events auf Lighting_1:**

```c
// btn_lighting Touch Release Event:
currentPage++
if(currentPage>=lightingPages)
{
  currentPage=0
}
page Lighting_2

// btn_electric Touch Release Event:
currentSection=1
currentPage=0
page Electric_1

// ... etc für andere Buttons
```

**Page Preinit Event:**
```c
// Highlight Lighting Button
btn_lighting.pco=2016
btn_electric.pco=65535
btn_water.pco=65535
btn_climate.pco=65535
btn_status.pco=65535
btn_power.pco=65535

// Seitenzähler
txt_page_counter.txt="1/2"

// Tracking
currentSection=6
currentPage=0
```

#### 2. ESPHome Sektion erstellen

Erstelle `esphome/sections/lighting.yaml`:

```yaml
# ============================================
# Lighting Section
# ============================================

sensor:
  - platform: homeassistant
    id: interior_light_brightness
    entity_id: light.interior
    attribute: brightness
    on_value:
      then:
        - lambda: |-
            char buffer[10];
            snprintf(buffer, sizeof(buffer), "%.0f%%", (x / 255.0) * 100.0);
            id(nextion_display).set_component_text("int_brightness", buffer);

binary_sensor:
  - platform: homeassistant
    id: interior_light_state
    entity_id: light.interior
    on_press:
      then:
        - lambda: |-
            id(nextion_display).set_component_text("int_status", "ON");
            id(nextion_display).set_component_value("int_status.pco", 2016);
    on_release:
      then:
        - lambda: |-
            id(nextion_display).set_component_text("int_status", "OFF");
            id(nextion_display).set_component_value("int_status.pco", 50712);

switch:
  - platform: homeassistant
    id: interior_light
    entity_id: light.interior
```

#### 3. In Haupt-Config importieren

In `motorhome-display.yaml`:

```yaml
packages:
  display_base: !include display-base.yaml
  alarms: !include display-alarms.yaml
  electric: !include sections/electric.yaml
  status: !include sections/status.yaml
  lighting: !include sections/lighting.yaml  # ← NEU
```

---

## Alarm-Schwellwerte anpassen

### Batterie-Schwellwerte ändern

In `display-alarms.yaml`:

```yaml
binary_sensor:
  - platform: template
    id: batterie_kritisch
    lambda: |-
      // Standard: < 20%
      return (id(batterie_soc).state < 20);
      
      // Anpassen: z.B. < 15%
      return (id(batterie_soc).state < 15);
```

### Eigene Alarm-Logik hinzufügen

```yaml
binary_sensor:
  # Beispiel: Temperatur-Alarm
  - platform: template
    id: temp_zu_hoch
    lambda: |-
      return (id(internal_temperature).state > 35.0);
    on_press:
      - script.execute: check_alarms
    on_release:
      - script.execute: check_alarms
```

Im `check_alarms` Script:

```yaml
script:
  - id: check_alarms
    then:
      - lambda: |-
          bool warning = false;
          
          // Bestehende Checks...
          if (id(batterie_kritisch).state) {
            warning = true;
          }
          
          // NEU: Temperatur-Check
          if (id(temp_zu_hoch).state) {
            warning = true;
          }
          
          // Rest wie gehabt...
```

---

## Layout ändern

### Andere Display-Größe (5")

**Nextion:**
- Resolution: 800x480 (gleich)
- Keine Anpassung nötig!

**Für 3.5" (480x320):**

```
Menu Width:  100px  (statt 150px)
Fonts:       -2pt   (z.B. Font 1 = 14pt statt 16pt)
Buttons:     w=100, h=60 (statt 150x80)
```

### Menu-Position ändern (rechts statt links)

**Nextion:**

1. Menu-Buttons verschieben:
   - Von: x=0
   - Zu: x=650 (800 - 150)

2. Content Area anpassen:
   - Von: x=150
   - Zu: x=0

### Horizontales Menu (oben)

```
┌─────────────────────────────────────────────────┐
│ Alert Text                                      │
├──────┬──────┬──────┬──────┬──────┬─────────────┤
│ Elec │Water │Clima │Statu │Power │  [Page]     │
├──────┴──────┴──────┴──────┴──────┴─────────────┤
│                                                 │
│                Content Area                     │
│                                                 │
└─────────────────────────────────────────────────┘
```

**Button-Größe:**
- w=150, h=50
- Position: y=50, x=0/150/300/450/600

---

## Farben anpassen

### Eigenes Farbschema

**Beispiel: Blaues Schema**

```yaml
# In display-alarms.yaml

script:
  - id: check_alarms
    then:
      - lambda: |-
          if (warning) {
            // Rot → Blau
            id(nextion_display).set_component_value("txt_alert.pco", 31);  // Blau
          } else if (caution) {
            // Orange → Türkis
            id(nextion_display).set_component_value("txt_alert.pco", 2047);  // Türkis
          } else {
            // Grün bleibt
            id(nextion_display).set_component_value("txt_alert.pco", 2016);
          }
```

**Farb-Rechner:**
```
RGB → Nextion Decimal
R: 0-31 (5 bit)
G: 0-63 (6 bit)
B: 0-31 (5 bit)

Dezimal = (R << 11) | (G << 5) | B

Beispiel Blau (0, 0, 255):
R=0, G=0, B=31
Dezimal = 31 = 0x001F
```

**Online-Tool**: [https://nextion.tech/color-converter/](https://nextion.tech/color-converter/)

---

## Zusätzliche Pages

### 3 Seiten pro Sektion

Aktuell: 2 Seiten (z.B. Electric_1, Electric_2)
Ziel: 3 Seiten (Electric_1, Electric_2, Electric_3)

**Nextion:**

1. **Add Page**: Electric_3 (Page 3)
2. Kopiere Komponenten von Electric_2
3. **Touch Events anpassen**:

   Electric_1:
   ```c
   // btn_electric → Weiter
   page Electric_2
   ```
   
   Electric_2:
   ```c
   // btn_electric → Weiter
   page Electric_3
   ```
   
   Electric_3:
   ```c
   // btn_electric → Zurück zu 1
   page Electric_1
   ```

4. **Seitenzähler anpassen**:
   - Electric_1: "1/3"
   - Electric_2: "2/3"
   - Electric_3: "3/3"

5. **Global Variable ändern**:
   ```c
   int electricPages=3  // Statt 2
   ```

---

## Beispiel-Templates

### Template: Gauge (Progress Bar)

```yaml
# ESPHome
sensor:
  - platform: homeassistant
    id: water_pressure
    entity_id: sensor.water_pressure
    on_value:
      then:
        - lambda: |-
            // Nextion Progress Bar "j0" (0-100)
            int percent = map(x, 0.0, 5.0, 0, 100);  // 0-5 bar → 0-100%
            id(nextion_display).set_component_value("j0.val", percent);
```

**Nextion:**
- Komponente: Progress Bar (j0)
- Range: 0-100
- pco: Farbe (Grün 2016)

### Template: Dual-State Button (On/Off)

```yaml
# ESPHome
binary_sensor:
  - platform: homeassistant
    id: pump_state
    entity_id: switch.water_pump
    on_press:
      - lambda: |-
          id(nextion_display).set_component_value("btn_pump.bco", 2016);  // Grün BG
          id(nextion_display).set_component_text("btn_pump", "ON");
    on_release:
      - lambda: |-
          id(nextion_display).set_component_value("btn_pump.bco", 63488);  // Rot BG
          id(nextion_display).set_component_text("btn_pump", "OFF");
```

**Nextion:**
- Komponente: Dual-state Button
- Text: "ON" / "OFF"
- bco: Wechselt zwischen Grün/Rot

---

## Best Practices

### 1. Naming Convention

```
Sensoren:     <section>_<name>        (electric_voltage)
Components:   <short>_<name>          (bat_volt, tank_fresh)
Pages:        <Section>_<number>      (Electric_1, Water_2)
```

### 2. Kommentare nutzen

```yaml
# In ESPHome
sensor:
  - platform: homeassistant
    id: batterie_spannung
    entity_id: sensor.battery_voltage
    # Updates Nextion "bat_volt" on Electric_1
    on_value:
      # ...
```

### 3. Fallback-Werte

```yaml
lambda: |-
  if (isnan(x)) {
    id(nextion_display).set_component_text("bat_volt", "---");
  } else {
    char buffer[10];
    snprintf(buffer, sizeof(buffer), "%.1fV", x);
    id(nextion_display).set_component_text("bat_volt", buffer);
  }
```

### 4. Logging

```yaml
lambda: |-
  ESP_LOGI("custom", "Updating fridge temp: %.1f°C", x);
  // ...
```

---

## Troubleshooting Customization

### "Component not found"

**Problem**: ESPHome kann Nextion-Komponente nicht finden

**Lösung:**
- Prüfe exakte Schreibweise (case-sensitive!)
- Prüfe ob Komponente auf aktueller Page existiert
- Nutze Logs: `ESP_LOGI("test", "Updating component xyz");`

### Farbe ändert sich nicht

**Problem**: `set_component_value("xxx.pco", color)` funktioniert nicht

**Lösung:**
- Prüfe ob Komponente dynamische Farbe unterstützt
- Teste mit bekannten Werten (2016=Grün, 63488=Rot)
- Prüfe Nextion-Komponente: `pco` muss editierbar sein

### Page-Wechsel funktioniert nicht

**Problem**: Touch Event führt nicht zur richtigen Page

**Lösung:**
- Prüfe Page-Name exakt (case-sensitive!)
- Prüfe Page-ID in Nextion
- Teste mit `page 1` (ID) statt `page Electric_1` (Name)

---

## Community-Beispiele

Nach dem Release werden hier Community-Anpassungen verlinkt:

- [ ] Integration mit Victron GX
- [ ] Solar-Dashboard mit Grafiken
- [ ] Wohnmobil-Leveling mit MPU6050
- [ ] GPS-Tracking mit Leaflet Maps

---

## Weitere Hilfe

- 📖 [Installation Guide](installation.md)
- 📖 [Nextion Page Structure](../nextion/docs/page-structure.md)
- 📖 [Design Guide](../nextion/docs/design-guide.md)
- 🐛 [GitHub Issues](https://github.com/CzarofAK/smartebl_display/issues)
- 💬 [Discussions](https://github.com/CzarofAK/smartebl_display/discussions)

**Viel Spaß beim Anpassen! 🎨**
