# ESPHome Configuration Files

Modulare ESPHome-Konfigurationen für das SmartEBL Display System.

## Inhalt

### 📦 Core Files

- **[display-base.yaml](display-base.yaml)** - ESP32 + Nextion UART Basis-Konfiguration
- **[display-alarms.yaml](display-alarms.yaml)** - Master Warning/Caution Alarm-System

### 🔧 Sections (`sections/`)

Modulare Sektionen zum Mix & Match:

- **[electric.yaml](sections/electric.yaml)** - Batterie, Solar, Shore Power
- **[water.yaml](sections/water.yaml)** - Wassertanks, Pumpen *(template)*
- **[climate.yaml](sections/climate.yaml)** - Heizung, Klima *(template)*
- **[status.yaml](sections/status.yaml)** - System-Status, Sicherungen, Tanks
- **[power.yaml](sections/power.yaml)** - Energie-Management *(template)*

### 📝 Examples (`examples/`)

- **[full-config.yaml](examples/full-config.yaml)** - Vollständiges Beispiel

## Quick Start

### Option 1: GitHub Packages (empfohlen)

```yaml
# Deine main.yaml
packages:
  display_base: github://CzarofAK/smartebl_display/esphome/display-base.yaml@main
  alarms: github://CzarofAK/smartebl_display/esphome/display-alarms.yaml@main
  electric: github://CzarofAK/smartebl_display/esphome/sections/electric.yaml@main
```

### Option 2: Lokale Files

```yaml
# Deine main.yaml
packages:
  display_base: !include display-base.yaml
  alarms: !include display-alarms.yaml
  electric: !include sections/electric.yaml
```

## Modulares System

**Importiere nur was du brauchst:**

```yaml
# Minimal (nur Status)
packages:
  display_base: !include display-base.yaml
  alarms: !include display-alarms.yaml
  status: !include sections/status.yaml

# Standard (Electric + Status)
packages:
  display_base: !include display-base.yaml
  alarms: !include display-alarms.yaml
  electric: !include sections/electric.yaml
  status: !include sections/status.yaml

# Vollständig (alle Sektionen)
packages:
  display_base: !include display-base.yaml
  alarms: !include display-alarms.yaml
  electric: !include sections/electric.yaml
  water: !include sections/water.yaml
  climate: !include sections/climate.yaml
  status: !include sections/status.yaml
  power: !include sections/power.yaml
```

## Anpassung

### Entity IDs ersetzen

In den Sektions-Files, ersetze alle `entity_id` mit deinen Home Assistant Entities:

```yaml
# Vorher (Template)
sensor:
  - platform: homeassistant
    id: batterie_spannung
    entity_id: sensor.battery_voltage  # ← ANPASSEN

# Nachher (Deine Entity)
sensor:
  - platform: homeassistant
    id: batterie_spannung
    entity_id: sensor.victron_battery_voltage  # ← DEINE ENTITY
```

### Eigene Sensoren hinzufügen

```yaml
# In deiner main.yaml
sensor:
  - platform: homeassistant
    id: mein_sensor
    entity_id: sensor.mein_sensor
    on_value:
      then:
        - lambda: |-
            id(nextion_display).set_component_text("nextion_comp", to_string(x).c_str());
```

Siehe [Customization Guide](../docs/customization.md) für Details.

## Secrets

Erstelle `secrets.yaml`:

```yaml
# WiFi
wifi_ssid: "Dein_WiFi_SSID"
wifi_password: "DeinWiFiPasswort"

# Fallback AP
ap_password: "FallbackPasswort123"

# API Encryption
api_encryption_key: "32-Zeichen-Key-hier"

# OTA
ota_password: "OTAPasswort123"
```

**Wichtig:** `secrets.yaml` ist in `.gitignore` und wird NICHT committet!

## Testing

```bash
# Syntax-Check
esphome config motorhome-display.yaml

# Kompilieren
esphome compile motorhome-display.yaml

# Flashen & Logs
esphome run motorhome-display.yaml

# Nur Logs
esphome logs motorhome-display.yaml
```

## Troubleshooting

### "logger baud_rate must be 0"

**Problem**: UART wird sowohl von logger als auch von Nextion genutzt.

**Lösung:**
```yaml
logger:
  baud_rate: 0  # UART für Nextion freigeben!
```

### "Component not found"

**Problem**: Nextion-Komponente existiert nicht oder falscher Name.

**Lösung:**
- Prüfe Nextion-Komponentennamen (case-sensitive!)
- Prüfe ob auf richtiger Page

### "Sensor unavailable"

**Problem**: Home Assistant Entity existiert nicht.

**Lösung:**
- Prüfe entity_id in Home Assistant
- Prüfe Rechtschreibung

Siehe [Troubleshooting Guide](../docs/troubleshooting.md) für mehr.

## File Structure

```
esphome/
├── display-base.yaml           # ESP32 + UART
├── display-alarms.yaml         # Alarm-Logik
├── sections/                   # Modulare Sektionen
│   ├── electric.yaml
│   ├── water.yaml
│   ├── climate.yaml
│   ├── status.yaml
│   └── power.yaml
└── examples/
    └── full-config.yaml        # Komplettes Beispiel
```

## Best Practices

1. ✅ Nutze `packages` für modularen Aufbau
2. ✅ Speichere Passwörter in `secrets.yaml`
3. ✅ Setze `logger: baud_rate: 0`
4. ✅ Teste mit `esphome config` vor dem Flashen
5. ✅ Nutze OTA nach erster USB-Flash

## Support

- 📖 [ESPHome Docs](https://esphome.io/)
- 📖 [Installation Guide](../docs/installation.md)
- 📖 [Customization Guide](../docs/customization.md)
- 🐛 [GitHub Issues](https://github.com/CzarofAK/smartebl_display/issues)
