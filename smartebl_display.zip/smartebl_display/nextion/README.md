# Nextion Display Files

Dieses Verzeichnis enthält alle Nextion-spezifischen Dokumentationen und Ressourcen.

## Inhalt

### 📖 Documentation (`docs/`)

- **[page-structure.md](docs/page-structure.md)** - Komplette Schritt-für-Schritt Anleitung für Nextion Editor
- **[design-guide.md](docs/design-guide.md)** - Design-Prinzipien und Best Practices
- **[component-reference.md](docs/component-reference.md)** - Referenz aller verwendeten Komponenten *(coming soon)*

### 🖼️ Screenshots (`screenshots/`)

- **[MOCKUPS.md](screenshots/MOCKUPS.md)** - ASCII-Art Mockups aller Display-Seiten

### 📦 Examples (`examples/`)

- Beispiel-Projekte *(coming soon)*

## Quick Start

1. **Nextion Editor installieren**: [Download](https://nextion.tech/nextion-editor/)
2. **Anleitung folgen**: [page-structure.md](docs/page-structure.md)
3. **Display flashen**: Via microSD oder USB-Serial

## Display-Spezifikationen

- **Modell**: NX8048P070 Enhanced (empfohlen)
- **Größe**: 7 Zoll
- **Resolution**: 800 x 480 pixels
- **Orientation**: Horizontal
- **Baud Rate**: 115200

## Wichtige Hinweise

⚠️ **Nextion .HMI Files können NICHT versioniert werden!**

Das .HMI-Format ist binär und proprietär. Änderungen an .HMI-Files können nicht mit Git getrackt werden.

**Best Practice:**
1. Erstelle regelmäßig Backups: `Project_v1.0.HMI`, `Project_v1.1.HMI`
2. Dokumentiere Änderungen in separaten Markdown-Files
3. Nutze die Dokumentation in `docs/` als Single Source of Truth

## Support

- 📖 [Nextion Documentation](https://nextion.tech/instruction-set/)
- 💬 [Nextion Forum](https://forum.nextion.tech/)
- 🐛 [SmartEBL Issues](https://github.com/CzarofAK/smartebl_display/issues)
