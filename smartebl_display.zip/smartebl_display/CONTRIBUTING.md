# Contributing to SmartEBL Display

Danke für dein Interesse, zu SmartEBL Display beizutragen! 🎉

## Wie kann ich beitragen?

### 🐛 Bug Reports

Gefunden einen Bug? [Öffne ein Issue](https://github.com/CzarofAK/smartebl_display/issues/new) mit:

- **Beschreibung** des Problems
- **Schritte zum Reproduzieren**
- **Erwartetes Verhalten**
- **Aktuelles Verhalten**
- **ESPHome/Nextion Versionen**
- **Logs** (falls relevant)

### 💡 Feature Requests

Idee für ein neues Feature? [Öffne ein Issue](https://github.com/CzarofAK/smartebl_display/issues/new) mit:

- **Beschreibung** des Features
- **Use Case** (Wofür brauchst du es?)
- **Beispiel-Implementation** (optional)

### 🔧 Code Contributions

1. **Fork** das Repository
2. **Clone** deinen Fork:
   ```bash
   git clone https://github.com/DEIN_USERNAME/smartebl_display.git
   cd smartebl_display
   ```
3. **Branch** erstellen:
   ```bash
   git checkout -b feature/mein-feature
   ```
4. **Änderungen** machen und committen:
   ```bash
   git add .
   git commit -m "Add: Mein tolles Feature"
   ```
5. **Push** zu deinem Fork:
   ```bash
   git push origin feature/mein-feature
   ```
6. **Pull Request** erstellen

## Coding Guidelines

### ESPHome Files

```yaml
# Kommentare verwenden
# ============================================
# SECTION NAME
# ============================================

# Klare Beschreibungen
sensor:
  - platform: homeassistant
    id: descriptive_id
    entity_id: sensor.clear_name  # ← ANPASSEN Kommentar
```

### Nextion Dokumentation

- **Markdown** verwenden
- **Screenshots** oder ASCII-Art für Layouts
- **Code-Beispiele** immer mit Kommentaren
- **Schritt-für-Schritt** Anleitungen

### Commit Messages

```
Format: <Type>: <Beschreibung>

Types:
- Add:    Neues Feature
- Fix:    Bug-Fix
- Update: Bestehende Funktionalität aktualisiert
- Docs:   Dokumentation
- Style:  Formatierung, keine Code-Änderung
- Refactor: Code-Umstrukturierung

Beispiele:
Add: Water section mit Tank-Level Display
Fix: Alarm-Check triggert bei falschen Werten
Docs: Installation Guide erweitert
Update: Batterie-Schwellwerte angepasst
```

## Testing

Vor dem Pull Request:

```bash
# ESPHome Syntax-Check
esphome config deine-config.yaml

# Teste auf echtem Hardware
esphome run deine-config.yaml
```

## Documentation

Neue Features benötigen:

- ✅ Code-Kommentare
- ✅ README Update (falls nötig)
- ✅ Beispiel-Config
- ✅ Anpassungs-Hinweise für User

## Community-Sektionen

Möchtest du eine eigene Sektion teilen? (z.B. "Lighting", "Security")

1. Erstelle `sections/deine-sektion.yaml`
2. Füge Beispiel-Config hinzu
3. Dokumentiere in `README.md`
4. Pull Request mit Label "community-section"

## Fragen?

- 💬 [GitHub Discussions](https://github.com/CzarofAK/smartebl_display/discussions)
- 🐛 [Issues](https://github.com/CzarofAK/smartebl_display/issues)

## Code of Conduct

- ✅ Respektvoll und konstruktiv
- ✅ Hilfreich gegenüber anderen
- ✅ Feedback annehmen
- ❌ Kein Spam, keine Beleidigungen

## License

Alle Contributions fallen unter [MIT License](LICENSE).

**Vielen Dank für deinen Beitrag! 🙏**
